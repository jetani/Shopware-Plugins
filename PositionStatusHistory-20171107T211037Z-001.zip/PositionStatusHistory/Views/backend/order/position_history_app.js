//{block name="backend/order/application" append}
    /**
     * Views
     */
    //{include file="backend/order/view/detail/position_window.js"}
    //{include file="backend/order/view/detail/position_history.js"}
//{/block}

